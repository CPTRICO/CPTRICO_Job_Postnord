Locales['en'] = {

	['blip_job']				= 'Postnord',

	--Vestiaire
	['no_outfit']			    = 'No clothing available',
	['open_cloakroom']			= 'Tryk ~INPUT_PICKUP~ at skifte',

	--Garage
	['sort_vehicle']			= 'Tryk ~INPUT_PICKUP~ for at hente bilen',
	['return_vehicle']			= 'Tryk ~INPUT_PICKUP~ at returnere bilen',
	['vehiclespawner']			= 'Vælg dit transportkøretøj.',

	--Livraison
	['Richman']					= 'Sektor : "~o~Richman Neighborhood~w~" ',
	['RockfordHills']		    = 'Sektor : "~g~Rockford Hills Neighborhood~w~" ',
	['Vespucci']				= 'Sektor : "~b~Vespucci Neighborhood~w~" ',
	['SLS']						= 'Sektor : "~y~Spud of Los Santos~w~" ',

	['join_next']				= '~g~[•] ~b~gå til ~w~ejendommen~r~ angivet på din GPS',
	['pickup']					= 'Tryk på ~INPUT_PICKUP~ for at levere',
	['must_be_walking']			= '~r~ [FEJL]: Du SKAL være på FOOT.',

	['cancel_delivery']			= '~r~Leveringer er annulleret !, Tilbage til depot.',
	['finish_delivery']			= '✉  ~o~Levering færdig, retur til depot.',

	['create_itinary']			= 'Jeg tog mig af opsætningen af ​​din GPS, du skal bare følge ruten',

	['not_enought_letter']		= '~r~Du mangler %s bogstaver.',
	['not_enought_colis']		= '~r~Du mangler %s pakker.',

	['gain']					= '~g~| 💰 | ~w~ Denne levering er blevet rapporteret ~g~%s $',

	--Distribution
	['open_distribution']		= 'Tryk på ~INPUT_PICKUP~ For at gendanne post og pakker',

	['letter']					= 'Brev',
	['colis']					= 'Pakke',

	['distribution']			= 'Distributionscenter',
	['deposit']					= 'Depositum',
	['pick']					= 'Opsamle',
	['take']					= 'Du har taget ~y~x %s %s ',
	['remove']					= 'Du har deponeret ~y~x %s %s',

	['player_cannot_hold']		= '~r~[FEJL]: Du KAN IKKE holde mere.',
	['not_enough']				= '~r~ [ERROR]: Ugyldig mængde.',

		-- Notification Delivery
	['notif_title_delivery']    = '~r~PostNord',
	['notif_district']			= '[Din sektor:] \ n ---------------------- \ n%s',	


}