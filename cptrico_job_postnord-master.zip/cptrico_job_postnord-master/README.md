

# Installation
1. Download ressourcen
2. Importer til "ressource" -filen på din server
3. Importer filen "gopostal_job.sql" til din database
4. Tilføj "start gopostal_job" i din server.cfg
5. Konfigurer "config.lua" -filen, hvis du ønsker det.


For eventuelle fejl, bedes du rapportere det til mig for at rette dem!
