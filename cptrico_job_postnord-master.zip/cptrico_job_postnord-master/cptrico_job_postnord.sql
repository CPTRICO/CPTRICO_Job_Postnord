--
-- Indholdet i tabellen `job`
--
INSERT INTO `jobs` (`name`, `label`) VALUES
('postnord', 'PostNord');

--
-- Indholdet i tabellen `job_grades`
--

INSERT INTO `job_grades` (`job_name`, `grade`, `name`, `label`, `salary`, `skin_male`, `skin_female`) VALUES
('postnord', 0, 'employee', 'Intérimaire', 200, '', '');

--
-- Indholdet i tabellen `items`
--

INSERT INTO `items` (`name`, `label`, `limit`, `rare`, `can_remove`) VALUES 
('letter', 'Courrier', '-1', '0', '1'), 
('colis', 'Colis', '-1', '0', '1');